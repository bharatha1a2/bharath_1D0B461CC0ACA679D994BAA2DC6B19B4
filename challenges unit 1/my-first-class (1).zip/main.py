def Hello_world():
  print("hello world")

Hello_world()